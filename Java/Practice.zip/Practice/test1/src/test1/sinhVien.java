/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test1;

/**
 *
 * @author Vu Thanh Binh
 */
public class sinhVien extends conNguoi{
    
    private String maSV;
    private double toan;
    private double ly;
    private double hoa;
    
    public void nhapTTSV(){
        
        nhapTT();
        System.out.println("Nhap ma SV:");
        maSV = inputString();
        System.out.println("Nhap diem toan:");
        toan = inputInt();
        System.out.println("Nhap diem ly:");
        ly = inputInt();
        System.out.println("Nhap diem hoa:");
        hoa = inputInt();
    }
    
    
    public void hienthiTTSV(){
        hienthiTT();
        System.out.println("Ma SV la:" + maSV);
        diemTB();
    }
    
    public void diemTB(){
        double diemTB;
        diemTB = ( toan+ ly + hoa)/3;
        System.out.println("Diem trung binh la:" + diemTB);
    }
    
}
