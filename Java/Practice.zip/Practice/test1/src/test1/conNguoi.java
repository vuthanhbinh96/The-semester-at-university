/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test1;

import java.util.Scanner;

/**
 *
 * @author Vu Thanh Binh
 */
public class conNguoi {
    
    private String hoten;
    private int namsinh;
    private String gioitinh;
    
    public int inputInt(){
        Scanner inp = new Scanner(System.in);
        int n = 0;
        n = inp.nextInt();
        return n;
    }
    
    public String inputString(){
        Scanner inp = new Scanner(System.in);
        String n = inp.nextLine();
        return n;
    }
    
    public void nhapTT(){
        System.out.println("Nhap ten:");
        hoten = inputString();
        System.out.println("Nhap nam sinh:");
        namsinh = inputInt();
        System.out.println("Nhap gioi tinh:");
        gioitinh = inputString();
    }
    
    public void hienthiTT(){
        System.out.println("Ten:"+hoten);
        System.out.println("Tuoi:"+ tuoi(namsinh));
        System.out.println("Gioi tinh:"+gioitinh);
    }
    
    public int tuoi(int n){
        int tuoi = 2016 - n;
        return tuoi;
    }
}
