/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test1;

import java.util.Scanner;

/**
 *
 * @author Vu Thanh Binh
 */
public class Test1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        
      /*  System.out.println("Nhap so luong nguoi");
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        conNguoi[] arr = new conNguoi[n];
        for(int i =0;i<n;i++){
            arr[i] = new conNguoi();
            arr[i].nhapTT();
        }
        
        for(int i =0;i<n;i++){
            System.out.println("danh sach:");
            arr[i].hienthiTT();
        }
*/
      sinhVien sv = new sinhVien();
      sv.nhapTTSV();
      sv.hienthiTTSV();
      
    }
    
}
