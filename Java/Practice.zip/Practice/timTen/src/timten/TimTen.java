/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timten;

/**
 *
 * @author Vu Thanh Binh
 */
public class TimTen {

    public static void tim(String str){
        
            System.out.println(str.indexOf("binh"));
    }
    
    
    public static void main(String[] args) {
        String s = "dkeubinhwipbinha ";
        tim(s);
    }
    
}
