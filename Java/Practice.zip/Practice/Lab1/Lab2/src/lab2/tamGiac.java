/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2;

import java.util.Scanner;

/**
 *
 * @author BinhBietBoi
 */
public class tamGiac {
    
    private int c1,c2,c3;
    private int cv;
    
    public void nhap(){
        Scanner inp = new Scanner(System.in);
        System.out.println("Nhap vao canh thu 1:");
        c1 = inp.nextInt();
        System.out.println("Nhap vao canh thu 2:");
        c2 = inp.nextInt();
        System.out.println("Nhap vao canh thu 3:");
        c3 = inp.nextInt();
    }
    
    public boolean KT(){
        if(c1+c2>c3 || c2+c3>c1 || c1+c3>c2)
            return true;
        else return false;
    }
    
    public int chuVi(){
        cv = c1+c2+c3;
        return cv;
    }
    
    public void ktTamGiac(){
        if(KT()==true){
            if(c1==c2&& c2==c3){
                System.out.println("Day la tam giac deu");
                System.out.println("Chu vi tam giac"+chuVi());
            }
                
            else
                if(c1==c2||c2==c3||c3==c1){
                    System.out.println("Day la tam giac can");
                    System.out.println("Chu vi tam giac"+chuVi());
                }
                else
                    {
                        System.out.println("Day la tam giac");
                        System.out.println("Chu vi tam giac"+chuVi());
                    }
            }
        else
            System.out.println("Day khong phai la tam giac");
    }
}
