/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2;

/**
 *
 * @author BinhBietBoi
 */
public class sinhVien extends conNguoi {
    public String maSV;
    public String lop;
    public double diemToan;
    public double diemLy;
    public double diemHoa;


    @Override
    public void inPut(){
        super.inPut();
        System.out.println("Nhập mã sinh viên: ");        
        maSV =  inPutString();
        System.out.println("Nhập lớp: ");        
        lop =  inPutString();
        System.out.println("Nhập điểm Toán: ");        
        diemToan = inPutInt();
        System.out.println("Nhập điểm Lý: ");        
        diemLy = inPutInt();     
        System.out.println("Nhập điểm Hóa: ");        
        diemHoa = inPutInt();
    }
    
  
    @Override
    public void outPut(){
        System.out.println("Mã sinh viên: "+ maSV);
        System.out.println("Lớp: "+ lop);
        System.out.println("Điểm Toán: "+ diemToan);
        System.out.println("Điểm Lý: "+ diemLy);
        System.out.println("Điểm Hóa: "+ diemHoa);

    }
}
