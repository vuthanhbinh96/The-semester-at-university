/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2;

import java.util.Scanner;

/**
 *
 * @author BinhBietBoi
 */
public class conNguoi {
    private String name;
    private int age;
    private String adress;
    private String sex;

    
    public void inPut(){
        System.out.print("Ten:");
        name = inPutString();
        System.out.print("Tuoi:");
        age = inPutInt();
        System.out.print("Dia chi:");
        adress = inPutString();
        System.out.print("Gioi tinh:");
        sex = inPutString();
    }
    
    public void outPut(){
        System.out.println("---------------------------");
        System.out.println("Họ tên: "+ name);
        System.out.println("Năm sinh: "+ age);        
        System.out.println("Địa chỉ: "+ adress);
        System.out.println("Giới tính: "+ sex);               

    }
    
    protected static int inPutInt(){
        Scanner inp = new Scanner(System.in);
        int n = 0;
        n = inp.nextInt();
        return n;
    }
    
    protected static String inPutString(){
        Scanner inp = new Scanner(System.in);
        String s = inp.nextLine();
        return s;
    }
    
}
