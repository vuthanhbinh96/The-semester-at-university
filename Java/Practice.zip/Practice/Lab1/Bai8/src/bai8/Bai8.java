/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8;

import java.util.Scanner;

/**
 *
 * @author BinhBietBoi
 */
public class Bai8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int s[] = null,n = 0;
        nhap(s,n);
        
    }
    public static void nhap(int a[],int n){
        Scanner inp = new Scanner(System.in);
        System.out.println("Nhap vao so phan tu:");
        n = inp.nextInt();
        a = new int[n];
        for(int i=0;i<n;i++){
            System.out.println("nhap s[" +i+"] =");
            a[i]=inp.nextInt();    
        }
    }
    
    public static void sapXep(int a[]){
        
    }
    
}
