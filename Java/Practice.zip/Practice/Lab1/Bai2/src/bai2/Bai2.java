/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai2;

import java.util.Scanner;

/**
 *
 * @author BinhBietBoi
 */
public class Bai2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n;
        Scanner inp = new Scanner(System.in);
        System.out.println("Nhap vao mot so nguyen bat ky");
        n = inp.nextInt();
        System.out.println("Cac so nguyen to la:");
        for(int i=1;i<n;i++){
            int tong=0; 
            for(int j=1;j<=i;j++){
                if(i%j==0)
                    tong++;
            }
            if(tong==2)
                System.out.println(i);
        }
    }
    
}
