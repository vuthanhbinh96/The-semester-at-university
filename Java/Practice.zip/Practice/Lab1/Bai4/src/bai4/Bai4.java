/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4;

import java.util.Scanner;

/**
 *
 * @author BinhBietBoi
 */
public class Bai4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Cac so thuan nghich doc co 6 chu so la:");
        for(int i=100000;i<999999;i++){
            int a=i/100000;
            int b=(i-a*100000)/10000;
            int c=(i-a*100000-b*10000)/1000;
            int d=(i-a*100000-b*10000-c*1000)/100;
            int e=(i-a*100000-b*10000-c*1000-d*100)/10;
            int f=i-a*100000-b*10000-c*1000-d*100-e*10;
            if(a==f && b==e && c==d)
                System.out.println(i);
        }
    }
    
}
