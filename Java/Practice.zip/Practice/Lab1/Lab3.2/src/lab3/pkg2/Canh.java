/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3.pkg2;

import java.util.Scanner;

/**
 *
 * @author BinhBietBoi
 */
public class Canh {
    private String tenCanh;
    private int chieudai;
    
    public void inPut(){
        chieudai = inPutInt();
        
    }
    
    public static int inPutInt(){
    Scanner inp = new Scanner(System.in);
    int n=0;
    n = inp.nextInt();
    return n;
    }

    public static String inPutString(){
    Scanner inp = new Scanner(System.in);
    String s = inp.nextLine();
    return s;
    }
        
        
}
