/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3.pkg2;

import java.util.Scanner;

/**
 *
 * @author BinhBietBoi
 */
public class DaGiac {
    
    private int socanh;
    Canh c[] = new Canh[100]; 
    
    public void nhapDaGiac(){
        System.out.print("Nhap so canh cua tam giac:");
        socanh = inPutInt();
        for(int i=0;i<socanh;i++){
            c[i];
        }
    }
    
    public int tinhChuVi(){
        int tong = 0;
        for(int i=0;i<socanh;i++){
            tong+=c[i];
        }
        return tong;
    }
    
    public void hienThi(){
        
    }
    
    public static int inPutInt(){
    Scanner inp = new Scanner(System.in);
    int n=0;
    n = inp.nextInt();
    return n;
    }

    public static String inPutString(){
    Scanner inp = new Scanner(System.in);
    String s = inp.nextLine();
    return s;
    }
}
