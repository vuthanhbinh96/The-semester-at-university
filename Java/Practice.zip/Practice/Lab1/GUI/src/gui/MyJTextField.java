/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.awt.GridLayout;
 
import javax.swing.JLabel;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class MyJTextField extends JFrame {
    JLabel lb;
    
    public MyJTextField() {
        
        // create JFrame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(2, 1, 5, 5));
 
        // Tạo và thêm JTextField vào frame
        JTextField tf = new JTextField(20);
        add(tf);
        
        // Thiết lập text cho TextField
        tf.setText("This is text of TextField");
 
        // Khởi tạo 1 JLabel và thêm vào Frame
        lb = new JLabel();
        add(lb);
        
        // Lấy nội dung text của TextField
        String text = tf.getText();
        // Gán nội dung text vừa lấy được 
   // từ TextField vào JLabel
        lb.setText(text);
        
        // Hiển thị Frame
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
 
    public static void main(String[] args) {
        new MyJTextField();
    }

}
