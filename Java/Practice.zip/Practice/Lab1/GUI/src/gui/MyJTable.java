/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.awt.GridLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;

import javax.swing.JRadioButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class MyJTable extends JFrame{
    public MyJTable() {

        // create JFrame
        setLayout(new GridLayout(1, 1, 15, 15));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500);

        // Khởi tạo 1 JTable
        JTable tbl = new JTable();
        // Khởi tạo 1 mảng String chứa các tiêu đề của cột
        String[] headers = new String[]
            {"Title 1", 
            "Title 2", 
            "Title 3", 
            "Title 4"};
        // Tạo 1 model cho table có tiêu đề cột và 0 hàng
        DefaultTableModel model = new DefaultTableModel(headers, 0);

        //Thêm dữ liệu cho Table.
        model.addRow(new String[]{"11", "12", "13", "14"});
        model.addRow(new String[]{"21", "22", "23", "24"});

        model.addColumn("Title 5", new String[]{"15", "25"});

        tbl.setModel(model);

        // Tạo thanh cuộn cho JTable khi kích thước 
        // của table vượt quá kích thước của khung chứa

        JScrollPane sp = new JScrollPane(tbl);
        add(sp);
        // Hiển thị Frame
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new MyJTable();
    }

}
