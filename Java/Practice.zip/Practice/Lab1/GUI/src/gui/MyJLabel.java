/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.awt.GridLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MyJLabel extends JFrame {
    public MyJLabel() {
       // Tạo layout cho Frame: thuộc loại GridLayout gồm 1 hàng, 3 cột, cách nhau theo chiều ngang 5px, dọc 5px
        setLayout(new GridLayout(1, 3, 5, 5));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 
       // Tạo hình ảnh icon
        Icon icon = new ImageIcon(getClass().getResource("old-television-set-icon_23-2147501665.jpg"));
 
        // Tạo label chỉ gồm Text
        JLabel lb1 = new JLabel("Label 1");
        // Tạo label chỉ có hình ảnh icon
        JLabel lb2 = new JLabel(icon);
        // Tạo label có cả text và icon
        JLabel lb3 = new JLabel("Icon and text", icon, JLabel.CENTER);
        lb3.setVerticalTextPosition(JLabel.BOTTOM);
        lb3.setHorizontalTextPosition(JLabel.CENTER);
 
       // Thêm 3 label vào frame
        add(lb1);
        add(lb2);
        //add(lb3);
 
       // Hiển thị JLabel lên
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
 
    public static void main(String[] args) {
        new MyJLabel();
    }
}

