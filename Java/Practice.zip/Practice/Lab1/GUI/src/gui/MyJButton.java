   /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener; 
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MyJButton extends JFrame {
    private JLabel lb;
 
    public MyJButton() {
        
        // Tạo frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        setLayout(new GridLayout(2, 1, 5, 5));
        setSize(500, 200);
        
        // Tạo 1 label
        lb = new JLabel("My JLabel");
        lb.setHorizontalAlignment(JLabel.CENTER);
        add(lb);
 
        // create JButton with text "Click Button"
        JButton btn = new JButton("Click Button");
        
        // Thêm sự kiện cho button. Ta sẽ tìm hiểu phần này ở chương tiếp
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                changeTextJLabel();
            }
        });
        
    // Thêm button vào Frame
        add(btn);
 
       // Hiển thị Frame
        pack();
        setLocationRelativeTo(null);
        setVisible(true);

    }
 
    // change text of lb
    private void changeTextJLabel() {
        lb.setText("You are clicked JButton");
    }
 
    public static void main(String[] args) {
        new MyJButton();
    }
}

