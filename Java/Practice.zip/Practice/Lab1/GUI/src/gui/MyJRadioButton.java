/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.awt.GridLayout;
import javax.swing.ButtonGroup;
 
import javax.swing.JRadioButton;
import javax.swing.JFrame;

public class MyJRadioButton extends JFrame{
    private javax.swing.ButtonGroup buttonGroup;
    
    public MyJRadioButton() {
        
        // create JFrame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(2, 1, 5, 5));
 
        // Khởi tạo 1 JRadioButton có text
        JRadioButton rdNam = new JRadioButton("Nam");
        
        // Khởi tạo 1 JRadioButton không có text
        JRadioButton rdNu = new JRadioButton();
        
   // Set text qua phương thức setText()
        rdNu.setText("Nữ");
        // Thiết lập JRadioButton được chọn
        rdNu.setSelected(true);
        
        add(rdNam);
        add(rdNu);
        
        // Khởi tạo ButtonGroup và thêm 
   // các thành phần thuộc nhóm đó
        buttonGroup = new ButtonGroup();
        buttonGroup.add(rdNu);
        buttonGroup.add(rdNam);
               
        
        // Hiển thị Frame
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
 
    public static void main(String[] args) {
        new MyJRadioButton();
    }

}
