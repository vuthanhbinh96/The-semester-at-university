/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.awt.GridLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
 
import javax.swing.JRadioButton;
import javax.swing.JFrame;

public class MyJComboBox extends JFrame{
    
    public MyJComboBox() {
        
        // create JFrame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 1, 15, 15));
 
        JComboBox jcbo1 = new JComboBox();
        JComboBox jcbo2 = new JComboBox();
        JComboBox jcbo3 = new JComboBox();
        add(jcbo1);
        add(jcbo2);
        add(jcbo3);
        

        // Cách 1. Sử dụng thông qua mảng
        // khởi tạo Model cho JComboBox
        String[] items = {"C#", ".NET", "Java", "PHP"};    
        DefaultComboBoxModel model1 = 
new DefaultComboBoxModel(items);
        jcbo1.setModel(model1);


        // Cách 2. Sử dụng thông qua Model, 
        // thêm các phần tử đơn lẻ
        DefaultComboBoxModel model2 = 
new DefaultComboBoxModel();

        model2.addElement("C#");
        model2.addElement(".NET");
        model2.addElement("Java");
        model2.addElement("PHP");
        model2.addElement("Python");
        jcbo2.setModel(model2);
        
        // Cách 3. Sử dụng trực tiếp trên JComboBox
        jcbo3.addItem("C#");
        jcbo3.addItem(".NET");
        jcbo3.addItem("Java");
        jcbo3.addItem("PHP");
        
        // Hiển thị Frame
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }
 
    public static void main(String[] args) {
        new MyJComboBox();
    }

}
