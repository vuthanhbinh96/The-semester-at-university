/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

import java.util.Scanner;

/**
 *
 * @author BinhBietBoi
 */
public class Lab1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String n;
        System.out.println("Nhap vao so nguyen:");
        Scanner inp = new Scanner(System.in);
        n = inp.nextLine();
        tinhTong(n);
    }

    public static void tinhTong(String n) {
        int tong = 0;
        for (int i = 0; i < n.length(); i++) {
            int a = (int) n.charAt(i) - 48;
            tong += a;
        }
        System.out.println("Tong cac chu so la:" + tong);
    }
}
