/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

import java.util.Scanner;

/**
 *
 * @author BinhBietBoi
 */
public class mayIn {
    private int trongLuong;
    private int namSanXuat;
    private String hangSanXuat;
    
    public void inPut(){
        System.out.print("Trọng lượng máy in:");
        trongLuong = inPutInt();
        System.out.print("Năm sản xuất:");
        namSanXuat = inPutInt();
        System.out.print("Hãng sản xuất:");
        hangSanXuat = inPutString();
    }
    
    public void outPut(){
        System.out.println("----------------");
        System.out.println("Trọng lượng máy in la "+trongLuong);
        System.out.println("Năm sản xuất là "+namSanXuat);
        System.out.println("Hãng sản xuất là "+hangSanXuat);
    }
    
    public int inPutInt(){
        Scanner inp = new Scanner(System.in);
        int n=0;
        n = inp.nextInt();
        return n;
    }
    
    public String inPutString(){
        Scanner inp = new Scanner(System.in);
        String s = inp.nextLine();
        return s;
    }
}
