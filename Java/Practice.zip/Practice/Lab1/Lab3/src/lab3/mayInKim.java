/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

/**
 *
 * @author BinhBietBoi
 */
public class mayInKim extends mayIn {
    private int soKim;
    private int tocDoIn;
    
    @Override
    public void inPut(){
        super.inPut();
        System.out.print("Nhập số kim máy in:");
        soKim = inPutInt();
        System.out.print("Nhập vào tốc độ in:");
        tocDoIn = inPutInt();
    }
    
    @Override
    public void outPut(){
        super.outPut();
        System.out.println("Số kim máy in là "+ soKim);
        System.out.println("Tốc độ in là "+tocDoIn);
    }
}
