/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package th2;

import java.util.Scanner;

/**
 *
 * @author BinhBietBoi
 */
public class Candidate {
    private String ma;
    private String ten;
    private int namsinh;
    protected int toan,van,anh;
    protected int n;
    
    public void inPut(){
        System.out.print("Nhap so luong thi sinh:");
        n = inPutInt();
        for(int i=0;i<n;i++){
            System.out.print("Ma thi sinh:");
            ma = inPutString();
            System.out.print("Ten thi sinh:");
            ten = inPutString();
            System.out.print("Nam sinh:");
            namsinh = inPutInt();
            System.out.print("Diem Toan:");
            toan = inPutInt();
            System.out.print("Diem Van:");
            van = inPutInt();
            System.out.print("Diem Anh:");
            anh = inPutInt();    
        } 
    }
    
    public void outPut(){
        System.out.println("-----------------");
        System.out.println("Ma thi sinh la "+ma);
        System.out.println("Ten thi sinh la "+ten);
        System.out.println("Nam sinh la "+namsinh);
        System.out.println("Diem toan la "+toan);
        System.out.println("Diem van la "+van);
        System.out.println("Diem anh la "+anh);
    }
    
    protected static int inPutInt(){
        Scanner inp = new Scanner(System.in);
        int n = 0;
        n= inp.nextInt();
        return n;      
    }
    
    protected static String inPutString(){
        Scanner inp = new Scanner(System.in);
        String s = inp.nextLine();
        return s;
    }
}
