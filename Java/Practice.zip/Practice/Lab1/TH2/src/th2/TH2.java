/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package th2;

/**
 *
 * @author BinhBietBoi
 */
public class TH2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Candidate ts = new Candidate();
        ts.inPut();     
        for(int i=0;i<ts.n;i++){
            if((ts.toan+ts.van+ts.anh)>15)
                ts.outPut();
        }
    }
    
}
