/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package th1;

import java.io.IOException;
import static java.lang.Math.sqrt;
import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class TH1 {

    /** 
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{  
        float a,b,c;
        int n;
        
        Scanner inp = new Scanner(System.in);
//        System.out.println("Nhap a:");
//        a = inp.nextFloat();
//        System.out.println("Nhap b:");
//        b = inp.nextFloat();
//        System.out.println("Nhap c:");
//        c = inp.nextFloat();
        System.out.println("Nhap n:");
        n = inp.nextInt();
        inp.close();
        
//        giaiPTBac2(a,b,c);
        tinhTong(n);
    }
    
    public static void giaiPTBac2(float a,float b,float c){
        float dental,kq1,kq2;
        
        if(a==0) {kq1=kq2=-c/b; System.out.printf("Phuong trinh co nghiem:%f",kq1);}
        else
        {
            dental= b*b-4*a*c;
            if(dental==0) System.out.printf("Phuong trinh co nghiem:%f",kq1=kq2=-b/(2*a));
            else
            {
                System.out.printf("Phuong trinh co 2 nghiem:%f va %f",kq1=(-b-(float)sqrt(dental))/(2*a),kq2=(-b+(float)sqrt(dental))/(2*a));
  
            }
        }
    }
    
    public static void tinhTong(int n){
        float E=1;
        
        for(float i=1;i<=n;i++){
            E+=1/i;
        }
        System.out.printf("Ket qua:" +E);
    }
    
}
