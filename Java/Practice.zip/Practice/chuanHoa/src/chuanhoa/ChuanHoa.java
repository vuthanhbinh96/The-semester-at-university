/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chuanhoa;

import java.util.Scanner;

/**
 *
 * @author Vu Thanh Binh
 */
public class ChuanHoa {

    
    
    
    public static String inputStr(){
        Scanner inp = new Scanner(System.in);
        String n = inp.nextLine();
        return n;
    }
    
    public  String khoangTrang(String str){
        str = str.trim();
        while(str.indexOf("  ")!=-1)
            str = str.replace("  "," ");
        return str;
    }
    
    public  String vietHoa(String str){
        str = khoangTrang(str);
        String temp[] = str.split(" ");
        str = "";
        for(int i = 0; i< temp.length;i++){
            str+= String.valueOf(temp[i].charAt(0)).toUpperCase() + temp[i].substring(1);
            if(i<temp.length-1)
                str+=" ";
        }
        return str;
    }
    
    public static void main(String[] args) {
        
        System.out.println("Nhap xau can chuan hoa:");
        String s = inputStr();
        ChuanHoa chx = new ChuanHoa();
        s = chx.vietHoa(s);
        System.out.println(s);
        
    }
    
}
