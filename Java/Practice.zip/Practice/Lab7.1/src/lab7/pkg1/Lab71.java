/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7.pkg1;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;


public class Lab71 extends JFrame {

    private JLabel lbMsg;
    private JLabel lbChar;
    private JLabel lbResult;
    private JLabel lbCountTime;
    private Timer timer;// Bộ đếm thời gian

    // Trạng thái đã hết giờ chơi chưa?
    private boolean isTimeOut = true;
    // Chữ cái hiện tại đang random ra
    private char currentChar;
    private int iCount = 0;// Đếm số lượng đúng
    private int currentTime = 60;

    public Lab71() {

        setSize(300, 200);
        setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initControls();
        initListener();
        initTimer();

        this.setVisible(true);
    }

	// Khởi tạo các Controls trên giao diện
    private void initControls() {

        lbCountTime = new JLabel("Thời gian: 60s");
        lbCountTime.setBounds(5, 5, 150, 25);
        lbCountTime.setForeground(Color.red);
        add(lbCountTime);

        lbResult = new JLabel("Số lượng đúng: ");
        lbResult.setBounds(155, 5, 150, 25);
        lbResult.setForeground(Color.blue);
        add(lbResult);

        lbChar = new JLabel("0");
        lbChar.setBounds(120, 30, 100, 100);
        lbChar.setFont(new Font("Tahoma", Font.BOLD, 64));
        add(lbChar);

        lbMsg = new JLabel("Nhấn phím Enter để bắt đầu!");
        lbMsg.setBounds(65, 120, 300, 25);
        lbMsg.setForeground(Color.red);
        add(lbMsg);
    }

	// Khởi tạo bộ lắng nghe sự kiện nhấn phím
// Ở đây ta chỉ quan tâm tới sự kiện KeyPressed
    private void initListener() {
        this.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}

            @Override
            public void keyPressed(KeyEvent e) {
                jframe_keyPress(e);
            }

            @Override
            public void keyReleased(KeyEvent e) {}
        });
    }

    // khởi tạo bộ đếm thời gian
    private void initTimer() {

        // Tạo 1 bộ đếm thời gian, cứ sau 1000 ms (1s) 
        // thì thực hiện hàm actionPerformed 1 lần
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                // Giảm thời gian còn lại đi 1
                currentTime--;
                lbCountTime.setText("Thời gian: " + currentTime);

                // Nếu thời gian còn lại là 0 (hết giờ)
                if (currentTime == 0) {
                    // Set biến trạng thái hết giờ và dừng đếm
                    isTimeOut = true;
                    timer.stop();
                }
            }
        });
    }

	// Sự kiện khi nhấn phím
    private void jframe_keyPress(KeyEvent e) {

        // Nếu nhấm Phím Enter
        if (e.getKeyCode() == 10) {

            iCount = 0;// Reset số lượng đếm
            currentTime = 60; // Reset thời gian còn lại

            //Random ra chữ cái đầu tiên
            currentChar = randomCharacter();
            lbChar.setText(currentChar + "");

            // Thiết đặt trạng thái hết giờ là sai
            isTimeOut = false;
            // Bắt đầu đếm thời gian
            timer.start();
        } else {

            // Nếu hết thời gian thì không được chơi nữa            
            if (isTimeOut == true) {
                return;
            }

            // Lấy ra phím được nhấn
            char keyTyped = e.getKeyChar();
            // Nếu phím vừa nhấn trùng với phím được random ra
            if (keyTyped == currentChar) {

                iCount++;// Tăng số đúng lên 1
                lbResult.setText("Số lượng đúng: " + iCount);
                lbMsg.setText("");

                // Random ra chữ mới
                currentChar = randomCharacter();
                lbChar.setText(currentChar + "");
            } else {
                // Nếu bấm không đúng thì thông báo ra JLabel
                lbMsg.setText("Sai rồi");
            }
        }
    }

    // Hàm random ra 1 chữ cái hoặc số bất kỳ
    private char randomCharacter() {

        String input = "1234567890abcdefghijklmnopqrstuvwxyz";

        Random rd = new Random();
        int index = rd.nextInt(input.length());
        return input.charAt(index);
    }

    
    public static void main(String[] args) {
        new Lab71();
    }    
}
