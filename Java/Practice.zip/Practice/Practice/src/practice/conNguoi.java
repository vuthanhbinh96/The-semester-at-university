/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practice;

import java.util.Scanner;

/**
 *
 * @author Vu Thanh Binh
 */
public class conNguoi extends Practice{
    public String hoten;
    public int namsinh;
    
    public conNguoi(){
     
    }
    
    public conNguoi(String hoten){
        this.hoten = hoten;
    }
    
        public static int nhapint(){
            Scanner inp = new Scanner(System.in);
            int n = 0;
            n = inp.nextInt();
            return n;
        }

        public static String nhapStr(){
            Scanner inp = new Scanner(System.in);
            String n = inp.nextLine();
            return n;
        }


        public int tuoi(int n){
            int tuoi;
            tuoi = 2016 - n;
            return tuoi;
        }
        
        public void nhapTT(){
            System.out.println("Nhap ten:");
            hoten = nhapStr();
            System.out.println("Nhap nam sinh:");
            namsinh = nhapint();
        }
        
        
        public void hienthiTT(){
            System.out.println("Ten:"+hoten);
            System.out.println("Tuoi:"+tuoi(namsinh));
        }
}
