/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBHelper {

    // Tạo biến tên cơ sở dữ liệu
    public static String dbName = "";

    // Phương thức kết nối tới cơ sở dữ liệu
    public Connection getConnectDB(String dbName) {
        Connection conn = null;
        try {
            String URL = 
                    "jdbc:sqlserver://127.0.0.1:1433;"
                    + "databaseName=" + dbName;
            String userName = "sa";
            String pwd = "";

            /*
            Trong đó: 
            - 127.0.0.1:1433 – Địa chỉ ip localhost 
            và port 1433 ta đã thiết lập.
            - userName và pwd là mật khẩu và password 
            của tài khoản đăng nhập vào SQLServer
             */
            Class.forName("com.microsoft.sqlserver."
                    + "jdbc.SQLServerDriver");
            conn = DriverManager.getConnection(
                    URL, userName, pwd);
            System.out.println("Kết nối thành công!");
        } catch (ClassNotFoundException | SQLException ex){
            System.out.println("Kết nối thất bại!");
        }
        return conn;
    }

    // Phương thức đóng kết nối
    public void CloseConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (Exception ex) {
            }
        }
    }

    public ResultSet ShowData(String sql) {
        Connection conn = getConnectDB(dbName);
        Statement state = null;
        ResultSet rs = null;
        try {
            state = conn.createStatement();
            rs = state.executeQuery(sql);
        } catch (Exception ex) {
        }
        return rs;
    }

    public boolean UpdateData(String sql) {
        Connection conn = getConnectDB(dbName);
        int row = 0;
        try {
            Statement state = (Statement) conn.createStatement();
            row = state.executeUpdate(sql);
            if (row > 0) {
                return true;
            }
        } catch (SQLException ex) {
            System.err.println("Error: " + ex.getMessage());
        } finally {
            CloseConnection(conn);
        }
        return false;
    }
}
