/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class SinhVien {
    // Khởi tạo đối tượng DBHelper

    public DBHelper dbHelper = new DBHelper();

    // Hàm khởi tạo SinhVien
    public SinhVien() {
        DBHelper.dbName = "SinhVien";
    }

    // Hiển thị dữ liệu
    public DefaultTableModel ShowData() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("STT");
        model.addColumn("ID");
        model.addColumn("Name");
        model.addColumn("Age");
        model.addColumn("Address");

        String sql = "Select * from sinhvien";
        try {
            ResultSet rs = dbHelper.ShowData(sql);
            int stt = 0;
            while (rs.next()) {
                stt++;
                model.addRow(
                        new Object[]{stt, 
                        rs.getString(0), 
                        rs.getString(1), 
                        rs.getString(2), 
                        rs.getString(3)});
            }
        } catch (SQLException ex) {
        }
        return model;
    }

    // Thêm dữ liệu
    public boolean InsertData(
            int id, String name, int age, String address) {
        String sql = "INSERT INTO sinhvien "
                + "values('" 
                + id + "', '" 
                + name + "', '" 
                + age + "', '" 
                + address + "')";

        if (dbHelper.UpdateData(sql)) {
            System.out.println("Thêm thành công!");
            return true;
        } else {
            System.out.println("Thêm thất bại!");
            return false;
        }
    }

    // Phương thức sửa thông tin sinh viên
    public boolean UpdateData(
            int id, String name, int age, String address) {
        String sql = "UPDATE sinhvien SET Name='" + name 
                + "', Address='" + address 
                + "', Age='" + age 
                + "' WHERE ID='" + id + "'";

        if (dbHelper.UpdateData(sql)) {
            System.out.println("Sửa thành công!");
            return true;
        } else {
            System.out.println("Sửa thất bại!");
            return false;
        }
    }

    // Hàm xóa sinh viên với id truyền vào
    public boolean Delete(int id) {
        String sql = 
          "DELETE FROM sinhvien WHERE ID='" + id + "'";

        if (dbHelper.UpdateData(sql)) {
            System.out.println("Xóa thành công!");
            return true;
        } else {
            System.out.println("Xóa thất bại!");
            return false;
        }
    }
}

