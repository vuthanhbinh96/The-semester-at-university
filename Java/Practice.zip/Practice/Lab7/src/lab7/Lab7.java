/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7;

import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Lab7 extends javax.swing.JFrame{

    public Lab7(){
        setSize(300,300);
        setLayout(null);
        this.setDefaultCloseOperation
                     (JFrame.EXIT_ON_CLOSE);        

        JLabel label1 = new JLabel();
        label1.setBounds(0, 0, 200, 30);        
        label1.setForeground(Color.red);
        label1.setText("Label 1");
        
        add(label1);               
        
        JLabel label2 = new JLabel();        
        label2.setBounds(0, 30, 200, 30);
        label2.setForeground(Color.blue);
        label2.setBackground(Color.LIGHT_GRAY);
        label2.setText("Label 2");
        label2.setOpaque(true);
        add(label2);
        
        JLabel label3 = new JLabel();        
        label3.setBounds(0, 60, 200, 30);
        label3.setForeground(Color.blue);
        label3.setText("Label 3");
        add(label3);
                        
        addMouseMotionListener(
                  new MouseMotionListener() {
            @Override
            public void mouseDragged(MouseEvent e) {
                
            }

            @Override
            public void mouseMoved(MouseEvent e) {
                label1.setText("Local Position: " + e.getX() + ":"  + e.getY());
                label2.setText("Screen Position: " + e.getXOnScreen()+ ":" + e.getYOnScreen());
            }
        });
        
        addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}

            @Override
            public void keyPressed(KeyEvent e) {
                label3.setText("Key Pressed: " + e.getKeyChar());
            }

            @Override
            public void keyReleased(KeyEvent e) {
                label3.setText("Key Released: " + e.getKeyChar());
            }
        });
        setVisible(true);
    }
    
    public static void main(String[] args) {
        new Lab7();
    }
}